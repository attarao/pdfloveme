Let's Encrypt / certbot quick instructions (run on server with domain DNS pointed to the server):

1. Temporarily expose nginx and ensure port 80 is reachable.
2. Run certbot in a container and place certs into ./certbot/conf using webroot plugin:
   docker run -it --rm --name certbot -v $(pwd)/certbot/www:/var/www/certbot -v $(pwd)/certbot/conf:/etc/letsencrypt certbot/certbot certonly --webroot -w /var/www/certbot -d yourdomain.com -m you@example.com --agree-tos --no-eff-email
3. After obtaining certs, update nginx/ssl.conf replacing DOMAIN_PLACEHOLDER with your domain and copy to nginx config, then restart nginx.
